import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.*;

public class FlappyBird extends JPanel implements ActionListener, KeyListener {
    int boardWidth = 360;
    int boardHeight = 640;
    int boardWidth2 = 210;
    int boardHeight2 = 100;

    //images

    //BACKGROUND
    Image flappybirdbg;

    //BACKGROUND PRETO
    Image bgpreto;

    //BIRD
    Image flappybird;

    //BIRD2
    Image flappybird2;

    //TOPPIPE
    Image toppipe;

    //DOWNPIPE
    Image bottompipe;

    //BIRD
    int birdX = boardWidth/8;
    int birdY = boardHeight/2;
    int birdwidth = 34;
    int birdHeight = 24;

    //BIRD2
    int bird2X = boardWidth/8;
    int bird2Y = boardHeight/2;
    int bird2width = 33;
    int bird2Height = 23;

    class Bird {
        int x = birdX;
        int y = birdY;
        int width = birdwidth;
        int height = birdHeight;
        Image img;

        Bird(Image img){
            this.img = img;
        }
    }

    class Bird2 {
        int x = bird2X;
        int y = bird2Y;
        int width = bird2width;
        int height = bird2Height;
        Image img2;

        Bird2(Image img2){
            this.img2 = img2;
        }
    }

    // Pipes
    int pipeX = boardWidth;
    int pipeY = 0;
    int pipeWidth = 64;
    int pipeHeight = 512;

    class Pipe {
        int x = pipeX;
        int y = pipeY;
        int width = pipeWidth;
        int height = pipeHeight;
        Image img;
        boolean passed = false;

        Pipe(Image img) {
            this.img = img;
        }
    }

    //game logic
    Bird bird;
    int velocityX = -4;
    int velocityY = 0;
    int gravity = 1;

    Bird2 bird2;
    int velocity2X = -4;
    int velocity2Y = 0;
    int gravity2 = 1;

    ArrayList<Pipe> pipes;
    Random random = new Random();

    Timer gameLoop;
    Timer placePipeTimer;
    boolean pause = false;
    boolean gameOver = false;
    double score = 0;
    boolean gameOver2 = false;
    double score2 = 0;

    FlappyBird() {
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setFocusable(true);
        addKeyListener(this);

        //load images
        flappybirdbg = new ImageIcon(getClass().getResource("/flappybirdbg.png")).getImage();
        bgpreto = new ImageIcon(getClass().getResource("/bgpreto.png")).getImage();
        flappybird = new ImageIcon(getClass().getResource("/flappybird.png")).getImage();
        flappybird2 = new ImageIcon(getClass().getResource("/flappybird2.png")).getImage();
        toppipe = new ImageIcon(getClass().getResource("/toppipe.png")).getImage();
        bottompipe = new ImageIcon(getClass().getResource("/bottompipe.png")).getImage();

        //bird
        bird = new Bird(flappybird);
        bird2 = new Bird2(flappybird2);
        pipes = new ArrayList<Pipe>();

        //place pipes timer
        placePipeTimer = new Timer(1500, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              // Code to be executed
            placePipes();
            }
        });
        placePipeTimer.start();

		//game timer
		gameLoop = new Timer(1000/60, this); //how long it takes to start timer, milliseconds gone between frames
        gameLoop.start();
	}
    
    void placePipes() {
        int randomPipeY = (int) (pipeY - pipeHeight/4 - Math.random()*(pipeHeight/2));
        int openingSpace = boardHeight/4;
    
        Pipe topPipe = new Pipe(toppipe);
        topPipe.y = randomPipeY;
        pipes.add(topPipe);
    
        Pipe bottomPipe = new Pipe(bottompipe);
        bottomPipe.y = topPipe.y  + pipeHeight + openingSpace;
        pipes.add(bottomPipe);
    }

    public void paintComponent(Graphics g) {
		super.paintComponent(g);
		draw(g);
	}

	public void draw(Graphics g) {
        //background
        g.drawImage(flappybirdbg, 0, 0, this.boardWidth, this.boardHeight, null);
        g.drawImage(bgpreto, 0, 0, this.boardWidth2, this.boardHeight2, null);

        //bird
        g.drawImage(flappybird, bird.x, bird.y, bird.width, bird.height, null);
        g.drawImage(flappybird2, bird2.x, bird2.y, bird2.width, bird2.height, null);

        //pipes
        for (int i = 0; i < pipes.size(); i++) {
            Pipe pipe = pipes.get(i);
            g.drawImage(pipe.img, pipe.x, pipe.y, pipe.width, pipe.height, null);
        }

        //score
        g.setColor(Color.YELLOW);

        g.setFont(new Font("Arial", Font.PLAIN, 32));
        if (gameOver) {
            g.drawString("Game Over: " + String.valueOf((int) score), 10, 35);
        }
        else {
            g.drawString("Player 1: " + String.valueOf((int) score), 10, 35);
        }

        g.setColor(Color.RED);

        g.setFont(new Font("Arial", Font.PLAIN, 32));
        if (gameOver2) {
            g.drawString("Game Over: " + String.valueOf((int) score2), 10, 85);
        }
        else {
            g.drawString("Player 2: " + String.valueOf((int) score2), 10, 85);
        }

        g.setColor(Color.BLACK);

        if(gameOver && gameOver2){
            if(score > score2){
                g.drawString("Player 1 WINS: " + String.valueOf((int) score), 50, 320);
            }
            if(score2 > score){
                g.drawString("Player 2 WINS: " + String.valueOf((int) score2), 50, 320);
            }
	}
    }
    public void move() {
        //bird
        velocityY += gravity;
        bird.y += velocityY;
        bird.y = Math.max(bird.y, 0); //apply gravity to current bird.y, limit the bird.y to top of the canvas
        velocity2Y += gravity2;
        bird2.y += velocity2Y;
        bird2.y = Math.max(bird2.y, 0); //apply gravity to current bird.y, limit the bird.y to top of the canvas

        //pipes
        for (int i = 0; i < pipes.size(); i++) {
            Pipe pipe = pipes.get(i);
            pipe.x += velocityX;
            pipe.x += velocity2X;

            if (!pipe.passed && bird.x > (pipe.x + pipe.width) && !gameOver) {
                score += 0.5; //0.5 because there are 2 pipes! so 0.5*2 = 1, 1 for each set of pipes
                //pipe.passed = true;
            }

            if (collision(bird, pipe)) {
                gameOver = true;
            }

            if (!pipe.passed && bird2.x > (pipe.x + pipe.width) && !gameOver2) {
                score2 += 0.5; //0.5 because there are 2 pipes! so 0.5*2 = 1, 1 for each set of pipes
                //pipe.passed = true;
            }
            //LINHA DE CODIGO QUE O STOR FEZ O || E "OU"    QUE JA DEU O SCORE PARA OS DOIS
            if (!pipe.passed && (bird.x > (pipe.x + pipe.width) || bird2.x > (pipe.x + pipe.width))) {
                pipe.passed = true;
            }

            if (collision(bird2, pipe)) {
                gameOver2 = true;
            }
            //score2++;
        }

        if (bird.y > boardHeight) {
            gameOver = true;
        }
        if (bird2.y > boardHeight) {
            gameOver2 = true;
        }
    }

    public boolean collision(Bird a, Pipe b) {
        return a.x < b.x + b.width &&   //a's top left corner doesn't reach b's top right corner
               a.x + a.width > b.x &&   //a's top right corner passes b's top left corner
               a.y < b.y + b.height &&  //a's top left corner doesn't reach b's bottom left corner
               a.y + a.height > b.y;    //a's bottom left corner passes b's top left corner
    }

    public boolean collision(Bird2 a, Pipe b) {
        return a.x < b.x + b.width &&   //a's top left corner doesn't reach b's top right corner
               a.x + a.width > b.x &&   //a's top right corner passes b's top left corner
               a.y < b.y + b.height &&  //a's top left corner doesn't reach b's bottom left corner
               a.y + a.height > b.y;    //a's bottom left corner passes b's top left corner
    }

    @Override
    public void actionPerformed(ActionEvent e) { //called every x milliseconds by gameLoop timer
        move();
        repaint();
        if (gameOver) {}

        if (gameOver2) {}

        if(gameOver && gameOver2){
            placePipeTimer.stop();
            gameLoop.stop();
        }
        if (pause) {
            placePipeTimer.stop();
            gameLoop.stop();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            velocityY = -9;
            if (gameOver) {
                bird.y = birdY;
                bird.x = birdX;
                velocityY = 0;
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_UP) {
            velocity2Y = -9;
            if (gameOver2) {
                bird2.y = bird2Y;
                velocity2Y = 0;
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            pause = !pause; // alterna entre true e false
            if (pause) {
                gameLoop.stop();
                placePipeTimer.stop();
            } else {
                gameLoop.start();
                placePipeTimer.start();
            }
        }
    }
    //not needed
    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyReleased(KeyEvent e) {}
}