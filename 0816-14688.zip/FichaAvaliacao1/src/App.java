public class App {public static void main(String[] args) {
    Professor professor = new Professor(12345, "Luis", "Santos", 1999, "Programação");
    Turma turma = new Turma("CX12345", "Programador de Informática", 2023, 2026);
    Aluno aluno1 = new Aluno("a14688", "Rui", "Leite", 2009,null);
    Aluno aluno2 = new Aluno("a14692", "Martim", "Amorim", 2008, null);
    Aluno aluno3 = new Aluno("a14712", "Tomas", "Ferreira", 2007,null);

    System.out.println(professor);
    System.out.println(professor.getNomeCompleto());
    System.out.println(turma);
    
    System.out.println(aluno1.toString());
    System.out.println(aluno1.getNomeCompleto());
    System.out.println(aluno1.getIdade());
    
    System.out.println(aluno2.toString());
    System.out.println(aluno2.getNomeCompleto());
    System.out.println(aluno2.getIdade());

    System.out.println(aluno3.toString());
    System.out.println(aluno3.getNomeCompleto());
    System.out.println(aluno3.getIdade());
    }
}
