public class Aluno {
        private String codigo ;
        private String nomeProprio ;
        private String nomeApelido ;
        private int anoNascimento ;
        
        public String getCodigo() {
            return codigo;
        }
        public void setCodigo(String codigo) {
            this.codigo = codigo;
        }
        public String getNomeProprio() {
            return nomeProprio;
        }
        public void setNomeProprio(String nomeProprio) {
            this.nomeProprio = nomeProprio;
        }
        public String getNomeApelido() {
            return nomeApelido;
        }
        public void setNomeApelido(String nomeApelido) {
            this.nomeApelido = nomeApelido;
        }
        public int getAnoNascimento() {
            return anoNascimento;
        }
        public void setAnoNascimento(int anoNascimento) {
            this.anoNascimento = anoNascimento;
        }
    
        @Override
        public String toString() {
            return "Aluno [codigo=" + codigo + ", nomeProprio=" + nomeProprio + ", nomeApelido=" + nomeApelido
                    + ", anoNascimento=" + anoNascimento + "]";
        }
        public Aluno() {
            codigo = "";
            nomeProprio = "";
            nomeApelido = "";
            anoNascimento = 0;
        }
        
        public Aluno(String codigo, String nomeProprio, String nomeApelido, int anoNascimento, String turma) {
            this.codigo = codigo;
            this.nomeProprio = nomeProprio;
            this.nomeApelido = nomeApelido;
            this.anoNascimento = anoNascimento;
        }
    
        public String getNomeCompleto(){
            return " Aluno " + nomeProprio + " " + nomeApelido;
        }
        public String getIdade(){
            int idade = 2025-anoNascimento;
            return " Idade " + idade;
    }
}
