public class Localizacao {
           
    private String pais;
    private String distrito;
    private String concelho;
    private String localidade;
    private String codigopostal;
    private String latitude;
    private String longitude;

    public Localizacao(String pais, String distrito, String concelho, String localidade, String codigopostal,
            String latitude, String longitude) {
        this.pais = pais;
        this.distrito = distrito;
        this.concelho = concelho;
        this.localidade = localidade;
        this.codigopostal = codigopostal;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Localizacao (){
        this.pais = "pais";
        this.distrito = "distrito"; 
        this.concelho = "concelho";
        this.localidade = "localidade";
        this.codigopostal = "codigopostal";
        this.latitude = "latitude";
        this.longitude = "longitude";
    }
    public String getPais() {
        return pais;
    }
    public void setPais(String pais) {
        this.pais = pais;
    }
    public String getDistrito() {
        return distrito;
    }
    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }
    public String getConcelho() {
        return concelho;
    }
    public void setConcelho(String concelho) {
        this.concelho = concelho;
    }
    public String getLocalidade() {
        return localidade;
    }
    public void setLocalidade(String localidade) {
        this.localidade = localidade;
    }
    public String getCodigopostal() {
        return codigopostal;
    }
    public void setCodigopostal(String codigopostal) {
        this.codigopostal = codigopostal;
    }
    public String getLatitude() {
        return latitude;
    }
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
    public String getLongitude() {
        return longitude;
    }
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "Localizacao [pais=" + pais + ", distrito=" + distrito + ", concelho=" + concelho + ", localidade="
                + localidade + ", codigopostal=" + codigopostal + ", latitude=" + latitude + ", longitude=" + longitude
                + "]";
    }

    

    
}