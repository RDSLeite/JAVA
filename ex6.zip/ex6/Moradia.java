public class Moradia {
           
        public String tipologia;
        public int numerodequartos;
        public int numerodewc;
        public Localizacao localidade;
        public int precodecompra;
        public int precodevenda;

    public void showInfo(){
        System.out.println("Info de Moradia");
        System.out.println("Tipologia: " + tipologia);
        System.out.println("N.quartos: " + numerodequartos);
        System.out.println("N.WcS :" + numerodewc);
        //System.out.println("Localidade: " + localidade);
        System.out.println("Preço Compra: " + precodecompra);
        System.out.println("Preço Venda: " + precodevenda);
    }

    public Moradia(String tipologia, int numerodequartos, int numerodewc, Localizacao localidade, int precodecompra,
            int precodevenda) {
        this.tipologia = tipologia;
        this.numerodequartos = numerodequartos;
        this.numerodewc = numerodewc;
        this.localidade = localidade;
        this.precodecompra = precodecompra;
        this.precodevenda = precodevenda;
    }

    @Override
    public String toString() {
        return "Moradia [tipologia=" + tipologia + ", numerodequartos=" + numerodequartos + ", numerodewc=" + numerodewc
                + ", localidade=" + localidade + ", precodecompra=" + precodecompra + ", precodevenda=" + precodevenda
                + "]";
    }
}