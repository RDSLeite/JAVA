class Second {
    public static void main(String[] args){

        //Moradia m1 = new Moradia();
        //Moradia m2 = new Moradia();

        Localizacao local1 = new Localizacao();
        Cliente cli1 = new Cliente("Luis" , 903333333 ,"abcde@oficina.pt");
        Moradia morada = new Moradia("T1", 3,2, local1, 165000, 165000);
        //System.out.println(cli1.toString());
        //System.out.println(local1.toString());
        System.out.println(morada.toString());

        /*m1.tipologia = "T1";
        m1.numerodequartos = 3;
        m1.numerodewc = 2;
        m1.localidade= "Famalicao";
        m1.precodecompra = 165000;
        m1.precodevenda = 165000;

        m1.showInfo();

        m2.tipologia = "T1";
        m2.numerodequartos = 3;
        m2.numerodewc = 2;
        m2.localidade= "Famalicao";
        m2.precodecompra = 190000;
        m2.precodevenda = 190000;

        m2.showInfo();*/

    }
}