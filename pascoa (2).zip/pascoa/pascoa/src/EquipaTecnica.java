import java.time.LocalDate;

public class EquipaTecnica {

    public String nome;
    public LocalDate datanascimento;
    public String funcao;

    public EquipaTecnica(String nome, LocalDate datanascimento, String funcao) {
        this.nome = nome;
        this.datanascimento = datanascimento;
        this.funcao = funcao;
    }

    public EquipaTecnica() {
        this.nome = "";
        this.datanascimento = LocalDate.of(1999,1,1);
        this.funcao = "";
    }

    public static void main(String[] args) {
        
    }
}