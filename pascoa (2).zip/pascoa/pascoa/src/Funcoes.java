public class Funcoes {

    public static int soma(int num1, int num2) {
        return(num1+num2);
    }
    public static int subtracao(int num1, int num2) {
        return(num1-num2);
    }
    public static int multiplicacao(int num1, int num2) {
        return(num1*num2);
    }
    /** metodo para dividir 2 numeros */
    public static double divisao(int num1, int num2) {
        if (num2 == 0){
            return 0;
        }
        return(num1/num2);
    }
}