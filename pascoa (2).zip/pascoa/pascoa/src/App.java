import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;


public class App {

    public static void main(String[] args) throws Exception {   
        
        Scanner scanner = new Scanner(System.in);

        int opcao = scanner.nextInt();
        do {
            menuPrincipal();
            opcao = scanner.nextInt();

        switch (opcao) {
            case 1:
            menuPrincipal();
                break;
            case 2:
                break;
            default:break;
        }
    }while (opcao !=0);

    scanner.close(); 
    }


    public static void lista() {
        ArrayList<Jogador> jogadores = new ArrayList<Jogador>();

        jogadores.add(new Jogador("Ruizadas",LocalDate.of(2000,1,1),
        "SUBLESIONADOS",
        "Avançado Fura Redes",
        1.75,
        65.0));

        Jogador jog1 = new Jogador("Ruizadas",LocalDate.of(2000,1,1),
        "SUBLESIONADOS",
        "Avançado Fura Redes",
        1.75,
        65.0);
        //jog1.nome = "Ruizadas";
        //jog1.escalao = "SUBLESIONADOS";
        
        Jogador jog2 = new Jogador();
        //jog2.nome = "FEBRAO";
        //jog2.escalao = "SUB21";
        jog2.setNome("FREBAO");
        jog2.setEscalao("SUB21");

        Jogador jog3 = new Jogador();
        //jog3.nome = "Santiago Piro.lito";
        //jog3.escalao = "SUB17";
        jog3.setNome("Santiago Piro.lito");
        jog3.setEscalao("SUB17");

        Jogador jog4 = new Jogador();
        //jog4.nome = "Granja";
        //jog4.escalao = "SUB10";
        jog4.setNome("Granja");
        jog4.setEscalao("SUB10");
        
        //System.out.println(jog1.toString());
        //System.out.println(jog2.toString());

        jogadores.add(jog2);
        jogadores.add(jog3);
        jogadores.add(jog4);

        //jogadores.remove(3);

        System.out.println("Tenho" + jogadores.size() + "jogadores \n");

        for (int i = 0; i < jogadores.size(); i++){
            System.out.print("#" + i + " : ");
            System.out.println(jogadores.get(i));
        }
    }
    public static void menuPrincipal(){
        System.out.println("Escolha uma opcao: ");
        System.out.println("Gerir Jogadores - 1: ");
        System.out.println("Gerir Equipa Tecnica - 2: ");
        System.out.println("Sair da Aplicacao - 0: ");
    }

    public void listarJogadores(){

        Scanner scanner = new Scanner(System.in);
        int opcao = 0;
        do {
            System.out.println("\n **** Gestao de Equipa : Jogadores **** \n");
            System.out.println("1- Listar Jogadores: ");
            System.out.println("2- Adicionar Jogador: ");
            System.out.println("3- Remover Jogador: ");
            System.out.println("");
            System.out.println("0- Voltar ao menu anterior ");
            
            opcao = scanner.nextInt();

        switch (opcao) {
            case 1:break;
            case 2:break;
            case 3:break;
            default:break;        
        
        }
    }while (opcao !=0);

        scanner.close();
    }
    public static void adicionarJogador(ArrayList<Jogador> jog, Jogador jogNew){}

    public void pedirDadosJogador(){}

    public void removeJogador(){}


}








































    /*public static void menu2(){
        System.out.println("Escolha uma opcao: ");
        System.out.println("Adicionar Jogadores - 1: ");
        System.out.println("Remover Jogadores - 2: ");
        System.out.println("Ver Lista - 3: ");
        Scanner ecolha2 = new Scanner(System.in);

        int opcao2 = ecolha2.nextInt();
        switch (opcao2) {
            case 1:
            
                break;
            case 2:
                break;
            case 3:
            lista();
                break;
            case 0:
                System.out.println("...");
                break;
        } 
    }
    public Jogador pedirDadosJogador(){
        //nome,year,mon,day,esc,pos,alt,peso;
        System.out.println("NOVO JOGADOR: ");
        System.out.println("como e que se vai chamar: ");
        System.out.println("em que ano nasceu: ");
        System.out.println("como e que se vai chamar: ");
        
        return new Jogador();
    }
    public static void addJogador(ArrayList<Jogador> jog, Jogador jogNew) {
        jog.add(jogNew);
    }
    public static void removeJogador(ArrayList<Jogador> jogg, Jogador jogOld) {
        jogg.remove(jogOld);
    }*/
