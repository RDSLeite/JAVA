import java.util.Scanner;
 
public class AppAnt {
    public static void main(String[] args) throws Exception {   
/* 
        Jogador jog1 = new Jogador();
        jog1.nome = "Ruizadas";
        jog1.escalao = "SUBLESIONADOS";
        
        Jogador jog2 = new Jogador();
        jog2.nome = "FEBRAO";
        jog2.escalao = "BUB21";

        Jogador jog3 = new Jogador();
        jog3.nome = "Santiago Piro.lito";
        jog3.escalao = "SUB17";

        Jogador jog4 = new Jogador();
        jog4.nome = "Granja";
        jog4.escalao = "SUB10";
*/
        /*System.out.println("Escolha uma opcao: ");
        System.out.println("Somar - 1: ");
        System.out.println("Subtrair - 2: ");
        System.out.println("Multiplicar - 3: ");
        System.out.println("Dividir - 4: ");
        System.out.println("Fechar o programa - 0: ");
        
        Scanner ecolha1 = new Scanner(System.in);

        int opcao = ecolha1.nextInt();
        
        switch (opcao) {
            case 1:
                soma();    
                break;
            case 2:
                subtracao();
                break;
            case 3:
                multiplicacao();
                break;
            case 4:
                divisao();
                break;
            case 0:
                System.out.println("...");
                break;        
        }
    }
    public static void soma() {
        System.out.println("escreve um numero: ");
        Scanner numero1 = new Scanner(System.in);
        int res1 = numero1.nextInt();

        System.out.println("escreve outro numero: ");
        Scanner numero2 = new Scanner(System.in);        
        int res2 = numero2.nextInt();
        
        System.out.println("A soma é: ");
        System.out.println(res1 + res2);


    }
    public static int somar(int x1, int x2) {
        return (x1+x2);
    }
    public static void subtracao() {
        System.out.println("escreve um numero: ");
        Scanner numero1 = new Scanner(System.in);
        int res1 = numero1.nextInt();

        System.out.println("escreve outro numero: ");
        Scanner numero2 = new Scanner(System.in);        
        int res2 = numero2.nextInt();
        
        System.out.println("A subtracao é: ");
        System.out.println(res1 - res2);

    }
    public static void multiplicacao() {
        System.out.println("escreve um numero: ");
        Scanner numero1 = new Scanner(System.in);
        int res1 = numero1.nextInt();

        System.out.println("escreve outro numero: ");
        Scanner numero2 = new Scanner(System.in);        
        int res2 = numero2.nextInt();
        
        System.out.println("A multiplicacao é: ");
        System.out.println(res1 * res2);

    }
    public static void divisao() {
        System.out.println("escreve um numero: ");
        Scanner numero1 = new Scanner(System.in);
        int res1 = numero1.nextInt();

        System.out.println("escreve outro numero: ");
        Scanner numero2 = new Scanner(System.in);        
        int res2 = numero2.nextInt();
        
        System.out.println("A divisao é: ");
        System.out.println(res1 / res2);*/
        
    }
}