import java.time.LocalDate;

public class App {public static void main(String[] args) throws Exception {

    Carro carro1 = new Carro("00-XX-02", LocalDate.of(2021, 1, 22),"Luis","Santos",4,"10,20€","carro","Gasóleo",95.000,true,4);
    Carro carro2 = new Carro("10-XX-02", LocalDate.of(2020, 1, 22),"Luis","Santos",4,"10,20€","carro","Gasóleo",95.000,true,7);
    Carro carro3 = new Carro("20-XX-02", LocalDate.of(2019, 1, 22),"Luis","Santos",4,"10,20€","carro","Gasóleo",95.000,true,5);
    Carro carro4 = new Carro("30-XX-02", LocalDate.of(2018, 1, 22),"Luis","Santos",4,"10,20€","carro","Gasóleo",95.000,true,2);

    Mota mota1 = new Mota("00-ZX-02", LocalDate.of(2022, 1, 22),"Luis","Santos",4,"10,20€","carro","Gasóleo",95.000,true,"Suporte de Mala Traseira");
    Mota mota2 = new Mota("00-YX-02", LocalDate.of(2022, 1, 22),"Luis","Santos",4,"10,20€","carro","Gasóleo",95.000,true,"Suporte de Mala Traseira");

    System.out.println(carro1.setClassico());
    System.out.println(carro2.setNumeroLugares());
    System.out.println(mota1.setSuporteMalas());
    System.out.println(mota2.etPagaIUC());

    System.out.println(carro1.getInfoCarro());
    System.out.println(carro2.getInfoCarro());
    System.out.println(carro3.getInfoCarro());
    System.out.println(carro4.getInfoCarro());

    System.out.println(mota1.getInfoMota());
    System.out.println(mota2.getInfoMota());
    }
}
