import java.time.LocalDate;
public class Carro {
    private String matricula;
    private LocalDate dataDaMatricula;
    private String marca;
    private String modelo;
    private int numeroRodas;
    private String iuc;
    private String tipoDeVeiculo;
    private String combustivel;
    private String kms;
    private boolean classico;
    private int numeroLugares;
    
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public LocalDate getDataDaMatricula() {
        return dataDaMatricula;
    }
    public void setDataDaMatricula(LocalDate dataDaMatricula) {
        this.dataDaMatricula = dataDaMatricula;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public int getNumeroRodas() {
        return numeroRodas;
    }
    public void setNumeroRodas(int numeroRodas) {
        this.numeroRodas = numeroRodas;
    }
    public String getIuc() {
        return iuc;
    }
    public void setIuc(String iuc) {
        this.iuc = iuc;
    }
    public String getTipoDeVeiculo() {
        return tipoDeVeiculo;
    }
    public void setTipoDeVeiculo(String tipoDeVeiculo) {
        this.tipoDeVeiculo = tipoDeVeiculo;
    }
    public String getCombustivel() {
        return combustivel;
    }
    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }
    public String getKms() {
        return kms;
    }
    public void setKms(String kms) {
        this.kms = kms;
    }
    public boolean isClassico() {
        return classico;
    }
    public void setClassico(boolean classico) {
        this.classico = classico;
    }
    public int getNumeroLugares() {
        return numeroLugares;
    }
    public void setNumeroLugares(int numeroLugares) {
        this.numeroLugares = numeroLugares;
    }

    @Override
    public String toString() {
        return "Carro [matricula=" + matricula + ", dataDaMatricula=" + dataDaMatricula + ", marca=" + marca
                + ", modelo=" + modelo + ", numeroRodas=" + numeroRodas + ", iuc=" + iuc + ", tipoDeVeiculo="
                + tipoDeVeiculo + ", combustivel=" + combustivel + ", kms=" + kms + ", classico=" + classico
                + ", numeroLugares=" + numeroLugares + "]";
    }

    public Carro(String matricula, LocalDate dataDaMatricula, String marca, String modelo, int numeroRodas, String iuc,
            String tipoDeVeiculo, String combustivel, String kms, boolean classico, int numeroLugares) {
        this.matricula = matricula;
        this.dataDaMatricula = dataDaMatricula;
        this.marca = marca;
        this.modelo = modelo;
        this.numeroRodas = numeroRodas;
        this.iuc = iuc;
        this.tipoDeVeiculo = tipoDeVeiculo;
        this.combustivel = combustivel;
        this.kms = kms;
        this.classico = classico;
        this.numeroLugares = numeroLugares;
    }
    public Carro() {
        this.matricula = "";
        this.dataDaMatricula = LocalDate.of(2022, 1, 22);
        this.marca = "";
        this.modelo = "";
        this.numeroRodas = 0;
        this.iuc = "";
        this.tipoDeVeiculo = "";
        this.combustivel = "";
        this.kms = "";
        this.classico = true;
        this.numeroLugares = 0;
    }

    /*public void getIdadeVeiculo(){
        int idadeCarro = 2025-dataDaMatricula;
            return " Idade " + idadeCarro;
    }*/

    public void getInfoCarro(){
        System.out.println("MATRICULA: \n" + matricula);
        System.out.println("DATADAMATRICULA: \n" + dataDaMatricula);
        System.out.println("MARCA : \n" + marca);
        System.out.println("MODELO: \n" + modelo);
        System.out.println("NUMERORODAS: \n" + numeroRodas);
        System.out.println("IUC: \n" + iuc);
        System.out.println("TIPODEVEICULO: \n" + tipoDeVeiculo);
        System.out.println("COMBUSTIVEL: \n" + combustivel);
        System.out.println("KMS: \n" + kms);
        System.out.println("CLASSICO: \n" + classico);
        System.out.println("NUMEROLUGARES: \n" + numeroLugares);
    }
}
