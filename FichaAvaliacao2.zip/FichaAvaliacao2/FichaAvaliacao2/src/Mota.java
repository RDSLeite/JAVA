import java.time.LocalDate;

public class Mota {
    private String matricula;
    private LocalDate dataDaMatricula;
    private String marca;
    private String modelo;
    private int numeroRodas;
    private String iuc;
    private String tipoDeVeiculo;
    private String combustivel;
    private String kms;
    private boolean pagaIUC;
    private String suporteMalas;
    
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public LocalDate getDataDaMatricula() {
        return dataDaMatricula;
    }

    public void setDataDaMatricula(LocalDate dataDaMatricula) {
        this.dataDaMatricula = dataDaMatricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getNumeroRodas() {
        return numeroRodas;
    }

    public void setNumeroRodas(int numeroRodas) {
        this.numeroRodas = numeroRodas;
    }

    public String getIuc() {
        return iuc;
    }

    public void setIuc(String iuc) {
        this.iuc = iuc;
    }

    public String getTipoDeVeiculo() {
        return tipoDeVeiculo;
    }

    public void setTipoDeVeiculo(String tipoDeVeiculo) {
        this.tipoDeVeiculo = tipoDeVeiculo;
    }

    public String getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }

    public String getKms() {
        return kms;
    }

    public void setKms(String kms) {
        this.kms = kms;
    }

    public boolean isPagaIUC() {
        return pagaIUC;
    }

    public void setPagaIUC(boolean pagaIUC) {
        this.pagaIUC = pagaIUC;
    }

    public String getSuporteMalas() {
        return suporteMalas;
    }

    public void setSuporteMalas(String suporteMalas) {
        this.suporteMalas = suporteMalas;
    }

    @Override
    public String toString() {
        return "Mota [matricula=" + matricula + ", dataDaMatricula=" + dataDaMatricula + ", marca=" + marca
                + ", modelo=" + modelo + ", numeroRodas=" + numeroRodas + ", iuc=" + iuc + ", tipoDeVeiculo="
                + tipoDeVeiculo + ", combustivel=" + combustivel + ", kms=" + kms + ", pagaIUC=" + pagaIUC
                + ", suporteMalas=" + suporteMalas + "]";
    }

    public Mota() {
        this.matricula = "";
        this.dataDaMatricula = LocalDate.of(2022, 1, 22);
        this.marca = "";
        this.modelo = "";
        this.numeroRodas = 0;
        this.iuc = "";
        this.tipoDeVeiculo = "";
        this.combustivel = "";
        this.kms = "";
        this.pagaIUC = true;
        this.suporteMalas = "";
    }

    public Mota(String matricula, LocalDate dataDaMatricula, String marca, String modelo, int numeroRodas, String iuc,
            String tipoDeVeiculo, String combustivel, String kms, boolean pagaIUC, String suporteMalas) {
        this.matricula = matricula;
        this.dataDaMatricula = dataDaMatricula;
        this.marca = marca;
        this.modelo = modelo;
        this.numeroRodas = numeroRodas;
        this.iuc = iuc;
        this.tipoDeVeiculo = tipoDeVeiculo;
        this.combustivel = combustivel;
        this.kms = kms;
        this.pagaIUC = pagaIUC;
        this.suporteMalas = suporteMalas;
    }

    /*public void getIdadeVeiculo(){
        int idadeCarro = 2025-dataDaMatricula;
            return " Idade " + idadeCarro;
    }*/

    public void getInfoMota(){
        System.out.println("MATRICULA: \n" + matricula);
        System.out.println("DATADAMATRICULA: \n" + dataDaMatricula);
        System.out.println("MARCA : \n" + marca);
        System.out.println("MODELO: \n" + modelo);
        System.out.println("NUMERORODAS: \n" + numeroRodas);
        System.out.println("IUC: \n" + iuc);
        System.out.println("TIPODEVEICULO: \n" + tipoDeVeiculo);
        System.out.println("COMBUSTIVEL: \n" + combustivel);
        System.out.println("KMS: \n" + kms);
        System.out.println("pagaIUC: \n" + pagaIUC);
        System.out.println("suporteMalas: \n" + suporteMalas);
        
    }
}
