import java.util.Scanner;  // Import the Scanner class

public class App {
    int num1,num2;
    public static void main(String[] args) throws Exception {
        //System.out.println("Digita um numero: ");
        /*int msg = scanner.nextInt();
        System.out.println("Digita um segundo numero: ");
        int msg1 = scanner.nextInt();
        int soma = (msg + msg1);
        System.out.println(soma);*/

        System.out.println("1 - Somar");
        System.out.println("2 - Subtrair");
        System.out.println("3 - Multiplicar");
        System.out.println("4 - Dividir");

        Scanner scanner = new Scanner(System.in);
        System.out.println("Escreva o numero");
        int num = scanner.nextInt();
        switch(num){
    
            case 1:
            Somar();
            break;

            case 2:
            Subtrair();
            break;

            case 3:
            Multiplicar();
            break;

            case 4:
            Dividir();
            break;
            
    
            } 
        }
        static void Somar(){
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n\n Num #1: ");
            int num1 = scanner.nextInt();
            System.out.println("\n\n Num #2: ");
            int num2 = scanner.nextInt();
            scanner.close();
            System.out.println("\n\n Soma = ");
            System.out.println(num1 + num2);
        }
        static void Subtrair(){
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n\n Num #1: ");
            int num1 = scanner.nextInt();
            System.out.println("\n\n Num #2: ");
            int num2 = scanner.nextInt();
            scanner.close();
            System.out.println("\n\n Subtrair = ");
            System.out.println(num1 - num2);
        }
        static void Multiplicar(){
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n\n Num #1: ");
            int num1 = scanner.nextInt();
            System.out.println("\n\n Num #2: ");
            int num2 = scanner.nextInt();
            scanner.close();
            System.out.println("\n\n Multiplição = ");
            System.out.println(num1 * num2);
        }
        static void Dividir(){
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n\n Num #1: ");
            int num1 = scanner.nextInt();
            System.out.println("\n\n Num #2: ");
            int num2 = scanner.nextInt();
            scanner.close();
            System.out.println("\n\n Dividir = ");
            System.out.println(num1 / num2);
        }
    }
