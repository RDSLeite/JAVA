public class Main {
  public static void main(String[] args) {
    String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
    for (int i = 0; i < cars.length; i++) {
      System.out.println(cars[i]);
    }
  }

    int[] numero = {1+2+3+4+5+6+7+8+9+10};
    for (int i = 0; i < numero.length; i++) {
      System.out.println(numero[i]);

      soma += numeros[i]
    }
  }

