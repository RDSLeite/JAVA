    public class Main {
        public static void main(String[] args) {
            int[][] myNumbers = {{1,1,1,1}, {5,5,5,5},{3,3,3,3}, {4,4,4,4,}};
            int elements = myNumbers[0].length;

            for (int i = 0; i < elements; ++i) {
                //System.out.println(":");
                int num1 = myNumbers[0][i];
                int num2 = myNumbers[elements-1][elements - i - 1];
                int num3 = myNumbers[1][i];
                int num4 = myNumbers[elements-2][elements - i - 1];
                System.out.println(num1 + num2);
                System.out.println(num3 + num4);
            }
        }
    }
