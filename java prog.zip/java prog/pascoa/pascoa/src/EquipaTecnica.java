import java.time.LocalDate;

public class EquipaTecnica {

    public String nome;
    public LocalDate dataNascimento;
    public String cargo;

    public EquipaTecnica(String nome, LocalDate dataNascimento, String cargo) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.cargo = cargo;
    }

    public EquipaTecnica() {
        this.nome = "";
        this.dataNascimento = LocalDate.of(1900, 1, 1);
        this.cargo = "";
    }

    public static void main(String[] args) {
        
    }
}
