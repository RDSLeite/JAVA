import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class App {

    public static void main(String[] args) throws Exception {

        Scanner scanner = new Scanner(System.in);
        int op = 0;

        do {
            menuPrincipal();
            op = scanner.nextInt();
            switch (op) {
                case 1 :
                    menuJogadores();
                    break;
            
                case 2 :
                    
                    break;
                
                default:
                
                    break;
            }
        } while (op != 0);

        scanner.close();
        
        
        /**jogadores.add(new Jogador(
            "Mateus Arante", 
            "Avançado só taps", 
            1.75,
            65.0, 
            LocalDate.of(2000, 1, 15), 
            "SUB17"
            ));

        /**Jogador jog1 = new Jogador(
            "Mateus Arante", 
            "Avançado só taps", 
            1.75,
            65.0, 
            LocalDate.of(2000, 1, 15),
            "SUB17"
            );
        //jog1.nome = "Mateus Arante";
        //jog1.escalao = "SUB17";

        
        Jogador jog2 = new Jogador();
        //jog2.nome = "Eduardo Machadinho";
        //jog2.escalao = "SUB17";
        jog2.setNome("Eduardo Machadinho");;
        jog2.setEscalao("SUB17");

        
        Jogador jog3 = new Jogador();
        jog3.setNome("Santizao");
        jog3.setEscalao("SUB19");

        
        Jogador jog4 = new Jogador();
        jog4.setNome("Tomas Granja");
        jog4.setEscalao("SUB17");
        jog4.getDataNascimento();
        jog4.setEscalao("SUB17");
        jog4.setEscalao("SUB17");
        jog4.setEscalao("SUB17");

        //Jogador jog5 = new Jogador();

        jogadores.add(jog2);
        jogadores.add(jog3);
        jogadores.add(jog4);

        //System.out.println("Tenho " + jogadores.size() + " jogadores \n");
        
        //jogadores.remove(3);

        //System.out.println(jogadores);**/
    }

    /**public static void gerirJogadores(ArrayList<Jogador> jogadores) {
        Scanner opcao = new Scanner(System.in);
        

        System.out.println("Escolha outra opcao: ");
        System.out.println("\n1 - Ver jogadores existentes na lista");
        System.out.println("\n2 - Adicionar jogadores à lista");
        System.out.println("\n3 - Remover jogadores à lista");
        int escolha2 = opcao.nextInt();
            switch (escolha2) {
                case 1:
                    for(int i = 0; i < jogadores.size(); i++) {
                        System.out.print("\n\n#" + i);
                        System.out.println(jogadores.get(i));
                    }
                    System.out.println("Queres escolher outra opcao? (1 - Sim; 2 - Nao)");
                    int escolha3 = opcao.nextInt();
                    if (escolha3 == 1) {
                        gerirJogadores(jogadores);
                    }
                    if (escolha3 == 2) {
                        break;
                    }
                    break;

                case 2:
                    System.out.println("Para adicionar um jogador precisamos primeiro da informacoes dele.");
                    System.out.println("Que nome é que tem o seu jogador?");
                    String nome = opcao.nextLine();
                    String nada1 = opcao.nextLine();
                    System.out.println("Que altura quer dar ao seu jogador?");
                    double altura = opcao.nextDouble();
                    System.out.println("Que posição é que o seu jogador tem?");
                    String posicao = opcao.nextLine();
                    String nada2 = opcao.nextLine();
                    System.out.println("Que peso quer dar ao seu jogador?");
                    double peso = opcao.nextDouble();
                    System.out.println("Em que ano é que o seu jogador nasceu?");
                    int ano = opcao.nextInt();
                    System.out.println("Em que mês é que o seu jogador nasceu?");
                    int mes = opcao.nextInt();
                    System.out.println("Em que dia é que o seu jogador nasceu?");
                    int dia = opcao.nextInt();
                    System.out.println("Em que escalao é que o seu jogador joga?");
                    String escalao = opcao.nextLine();
                    String nada3 = opcao.nextLine();
                    
                    Jogador jogAdd = new Jogador(nome, posicao, altura, peso, LocalDate.of(ano, mes, dia), escalao);
                    jogadores.add(jogAdd);
                    
                    System.out.println("Quer realizar outra operacao? (1 - Sim; 2 - Nao)");
                    int escolha4 = opcao.nextInt();
                    if (escolha4 == 1) {
                        gerirJogadores(jogadores);
                    }
                    if (escolha4 == 2) {
                        break;
                    }
                    break;

                case 3:
                    System.out.println("Para remover um jogador precisa de ver qual da lista quer remover, deseja ver a lista? (1 - Sim; 2 - Nao)");
                    int escolha5 = opcao.nextInt();
                    if (escolha5 == 1) {
                        for(int i = 0; i < jogadores.size(); i++) {
                            System.out.print("\n\n#" + i);
                            System.out.println(jogadores.get(i));
                        }
                    }
                    if (escolha5 == 2) {
                        
                    }
                    break;
                
                default:
                    break;
            }
    }**/

    public static void menuPrincipal() {
        System.out.println("BEM VINDO | MENU \n\n Escolha uma opcao: ");
        System.out.println("\n1 - Gerir Jogadores");
        System.out.println("\n2 - Gerir Equipa Técnica");
        System.out.println("\n0 - Sair da App");
    }

    public static void menuJogadores() {
        Scanner scanner = new Scanner(System.in);
        int op = 0;

        do {
            System.out.println("GESTAO DA EQUIPA - JOGADORES: ");
            System.out.println("ESCOLHA UMA OPCAO: ");
            System.out.println("\n1 - Ver jogadores existentes na lista");
            System.out.println("\n2 - Adicionar jogadores à lista");
            System.out.println("\n3 - Remover jogadores à lista");
            System.out.println("\n0 - Voltar ao menu anterior");
            
            op = scanner.nextInt();

            switch (op) {
                case 1 :
                    break;
            
                case 2 :
                    break;
                
                case 3 :
                    break;

                default:
                
                    break;
            }

        } while (op != 0);

        //scanner.close();
    }

    public static void verLista() {
        /**jogadores.add(new Jogador(
            "Mateus Arante", 
            "Avançado só taps", 
            1.75,
            65.0, 
            LocalDate.of(2000, 1, 15), 
            "SUB17"
            ));

        Jogador jog2 = new Jogador();
        jog2.setNome("Eduardo Machadinho");;
        jog2.setEscalao("SUB17");
        jog2.setDataNascimento(LocalDate.of(2008, 5, 5));
        jog2.setAltura(1.75);
        jog2.setPeso(65);
        jog2.setPosicao("Banco Com Cobertor");

        
        Jogador jog3 = new Jogador();
        jog3.setNome("Santizao");
        jog3.setEscalao("SUB19");
        jog3.setDataNascimento(LocalDate.of(2009, 12, 24));
        jog3.setAltura(1.60);
        jog3.setPeso(50);
        jog3.setPosicao("Extremo/TT");

        
        Jogador jog4 = new Jogador();
        jog4.setNome("Tomas Granja");
        jog4.setEscalao("SUB17");
        jog4.setDataNascimento(LocalDate.of(2020, 2, 30));
        jog4.setAltura(1.70);
        jog4.setPeso(60);
        jog4.setPosicao("Ponta Queta");

        jogadores.add(jog2);
        jogadores.add(jog3);
        jogadores.add(jog4);

        for(int i = 0; i < jogadores.size(); i++) {
            System.out.print("\n\n#" + i);
            System.out.println(jogadores.get(i));
        }**/
    }

    public static void adicionarJogadores(ArrayList<Jogador> jogadores, Jogador jogNew) {
        
    }

    public static void removerJogador() {

    }

    public static void atualizarJogadores() {

    }
}
