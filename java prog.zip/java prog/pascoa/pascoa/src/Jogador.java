import java.time.LocalDate;

class Jogador {
        private String nome;
        private int idade;
        private String posicao;
        private LocalDate dataNascimento;


        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getIdade() {
            return idade;
        }

        public void setIdade(int idade) {
            this.idade = idade;
        }

        public String getPosicao() {
            return posicao;
        }

        public void setPosicao(String posicao) {
            this.posicao = posicao;
        }

        public LocalDate getDataNascimento() {
            return dataNascimento;
        }

        public void setDataNascimento(LocalDate dataNascimento) {
            this.dataNascimento = dataNascimento;
        }


        public Jogador(String nome, int idade, String posicao, LocalDate dataNascimento) {
            this.nome = nome;
            this.idade = idade;
            this.posicao = posicao;
            this.dataNascimento = dataNascimento;
        }


        public Jogador() {
            this.nome = "";
            this.idade = 0;
            this.posicao = "";
            this.dataNascimento = LocalDate.of(1900, 1, 1);
        }


        @Override
        public String toString() {
            return "Jogador [nome=" + nome + ", idade=" + idade + ", posicao=" + posicao + ", dataNascimento="
                    + dataNascimento + "]";
        }
}

/*public class Jogador {
    
    private String nome;
    private String posicao;
    private double altura;
    private double peso;
    private LocalDate dataNascimento;
    private String escalao;

    public static void main(String[] args) {
        
    }

    public Jogador(String nome, String posicao, double altura, double peso, LocalDate dataNascimento, String escalao) {
        this.nome = nome;
        this.posicao = posicao;
        this.altura = altura;
        this.peso = peso;
        this.dataNascimento = dataNascimento;
        this.escalao = escalao;
    }

    public Jogador() {
        this.nome = "";
        this.posicao = "";
        this.altura = 0;
        this.peso = 0;
        this.dataNascimento = LocalDate.of(1900, 1, 1);
        this.escalao = "";
    }

    @Override
    public String toString() {
        return "\nNome = " + nome + "\nPosicao = " + posicao + "\nAltura = " + altura + "\nPeso = " + peso
                + "\nDataNascimento = " + dataNascimento + "\nEscalao = " + escalao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPosicao() {
        return posicao;
    }

    public void setPosicao(String posicao) {
        this.posicao = posicao;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getEscalao() {
        return escalao;
    }

    public void setEscalao(String escalao) {
        this.escalao = escalao;
    }

    
}*/
