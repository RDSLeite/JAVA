import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;


public class AppRes {
    static ArrayList<Jogador> jogadores = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1 - Gerir Jogadores");
            System.out.println("2 - Gerir Equipa Técnica");
            System.out.println("0 - Sair da Aplicação");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    gerirJogadores();
                    break;
                case 2:
                    System.out.println("Funcionalidade de gerir equipa técnica não implementada.");
                    break;
                case 0:
                    System.out.println("A sair da aplicação...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    private static void gerirJogadores() {
        int escolha;
        do {
            System.out.println("\nGerir Jogadores:");
            System.out.println("1 - Ver Jogadores Existentes na Lista");
            System.out.println("2 - Adicionar Jogador à Lista");
            System.out.println("3 - Remover Jogador da Lista");
            System.out.println("0 - Voltar");
            System.out.print("Escolha: ");
            escolha = scanner.nextInt();
            scanner.nextLine();

            switch (escolha) {
                case 1:
                    verJogadores();
                    break;
                case 2:
                    adicionarJogador();
                    break;
                case 3:
                    removerJogador();
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (escolha != 0);
    }

    public static void verJogadores() {
        if (jogadores.isEmpty()) {
            System.out.println("Nenhum jogador na lista.");
        } else {
            for (int i = 0; i < jogadores.size(); i++) {
                System.out.println((i + 1) + ". " + jogadores.get(i));
            }
        }
    }

    public static void adicionarJogador() {
        System.out.print("Nome do Jogador: ");
        String nome = scanner.nextLine();
        System.out.print("Idade do Jogador: ");
        int idade = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Posição do Jogador: ");
        String posicao = scanner.nextLine();
        System.out.print("Ano que nasceu: ");
        int ano = scanner.nextInt();
        System.out.print("Mes que nasceu: ");
        int mes = scanner.nextInt();
        System.out.print("Dia que nasceu: ");
        int dia = scanner.nextInt();

        jogadores.add(new Jogador(nome, idade, posicao, LocalDate.of(ano, mes, dia)));
        System.out.println("Jogador adicionado com sucesso!");
    }

    public static void removerJogador() {
        verJogadores();
        if (!jogadores.isEmpty()) {
            System.out.print("Número do jogador a remover: ");
            int index = scanner.nextInt();
            scanner.nextLine();
            if (index > 0 && index <= jogadores.size()) {
                jogadores.remove(index - 1);
                System.out.println("Jogador removido com sucesso!");
            } else {
                System.out.println("Número inválido.");
            }
        }
    }
}

